#!/bin/sh
sleep 300

su - mas -c 'sh /home/mas/eie/opt/apache-tomcat8011/bin/startup.sh'

